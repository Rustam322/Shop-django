from django.contrib import admin
from .models import Category, Product, Gallery

# Register your models here.

class CategoryAdmin(admin.ModelAdmin):
    list_display = ['pk', 'title']
    prepopulated_fields = {'slug': ('title', )}


class GalleryInline(admin.TabularInline):
    model = Gallery
    fk_name = 'product'
    extra = 1


class ProductAdmin(admin.ModelAdmin):
    list_display = ['pk', 'title', 'quantity', 'price', 'created_at']
    list_editable = ['quantity', 'price']
    prepopulated_fields = {'slug': ('title', )}
    list_display_links = ['pk', 'title']
    inlines = [GalleryInline]

admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, ProductAdmin)
