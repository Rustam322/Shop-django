from django.shortcuts import render, redirect
from django.urls import reverse

from .models import Category, Product
from django.views.generic import ListView, DetailView
from .forms import LoginForm, RegistrationForm, CustomerForm, ShippingForm
from django.contrib.auth import login, logout
from django.contrib import messages
from .utils import CartForAuthenticatedUser, get_cart_data
from shop import settings
import stripe
# Create your views here.


class ProductList(ListView):
    model = Product
    extra_context = {
        'title': 'TOTEMBO: Главная страница'
    }
    template_name = 'store/product_list.html'
    context_object_name = 'categories'

    def get_queryset(self):
        categories = Category.objects.all()
        data = []
        for category in categories:
            products = category.products.all()[:4]

            if category.image:
                image = category.image.url
            else:
                image = 'https://экологиякрыма.рф/img/19893719.jpg'

            data.append({
                'title': category,
                'products': products,
                'image': image
            })
        return data


class ProductListByCategory(ListView):
    model = Product
    context_object_name = 'products'
    template_name = 'store/category_detail.html'


    def get_queryset(self):
        sort_field = self.request.GET.get('sort')
        category = Category.objects.get(slug=self.kwargs['slug'])
        products = Product.objects.filter(category=category)
        if sort_field:
            products = products.order_by(sort_field)
        return products

    def get_context_data(self, *, object_list=None, **kwargs):
        context = super().get_context_data()
        category = Category.objects.get(slug=self.kwargs['slug'])
        context['title'] = f'Категория: {category.title}'
        return context


class ProductDetail(DetailView): # product_detail.html
    model = Product
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data()
        product = Product.objects.get(slug=self.kwargs['slug'])
        context['title'] = f'Товар - {product.title}'
        products = Product.objects.all()
        data = []
        for i in range(4):
            from random import randint
            random_index = randint(0, len(products) - 1)
            p = products[random_index]
            if p not in data:
                data.append(p)
        context['products'] = data


        return context


def login_registration(request):
    context = {
        'title': 'Войти или зарегестрироваться',
        'login_form': LoginForm(),
        'registration_form': RegistrationForm()
    }
    return render(request, 'store/login_registration.html', context)


def user_login(request):
    form = LoginForm(data=request.POST)
    if form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect('product_list')
    else:
        messages.error(request, 'Не верное имя пользователя или пароль')
        return redirect('login_registration')


def user_logout(request):
    logout(request)
    return redirect('product_list')


def register(request):
    form =RegistrationForm(data=request.POST)
    if form.is_valid():
        user = form.save()
        messages.success(request, 'Аккаунт успешно создан. Войдите в Аккаунт')
    else:
        for error in form.errors:
            messages.error(request, form.errors[error][0])



def cart(request):
    cart_info = get_cart_data(request)

    return render(request, 'store/cart.html', context=cart_info)


def to_cart(request, product_id, action):
    if request.user.is_authenticated:
        user_cart = CartForAuthenticatedUser(request, product_id, action)
        return redirect('cart')
    else:
        return redirect('login_registration')


def checkout(request):
    cart_info = get_cart_data(request)
    context = {
        'cart_total_quantity': cart_info['cart_total_quantity'],
        'order': cart_info['order'],
        'items': cart_info['products'],
        'title': 'Сделать заказ',
        'customer_form': CustomerForm(),
        'shipping_form': ShippingForm()
    }
    return render(request, 'store/checkout.html', context)


def create_checkout_session(request):
    stripe.api_key = settings.STRIPE_SECRET_KEY
    if request.method == 'POST':
        user_cart = CartForAuthenticatedUser(request)
        cart_info = user_cart.get_cart_info()

        total_price = cart_info['cart_total_price']
        total_quantity = cart_info['cart_total_quantity']
        session = stripe.checkout.Session.create(
            line_items=[
                {
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': 'Товары с TOTEMBO'
                        },
                        'unit_amount': int(total_price * 100)
                    },
                    'quantity': total_quantity
                }
            ],
            mode='payment',
            success_url=request.build_absolute_uri(reverse('successPayment')),
            cancel_url =request.build_absolute_uri(reverse('successPayment'))
        )
        return redirect(session.url, 303)


def successPayment(request):
    user_cart = CartForAuthenticatedUser(request)
    user_cart.clear()
    messages.success(request, 'Оплата прошла успешно')
    return render(request, 'store/success.html')

